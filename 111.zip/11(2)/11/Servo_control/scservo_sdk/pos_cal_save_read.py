# my_sdk/pose_utils.py
import json
from .sms_sts import *
from typing import List, Dict, Tuple, Optional, Union


def cal_pos_change(
    current_pos_array: List[Optional[float]],
    target_pos_array: List[Optional[float]]
) -> List[Optional[float]]:
    """
    计算单个目标位姿相对当前位姿的变化量（目标 - 当前）
    :param current_pos_array: 当前位置数组 可含None,对应舵机读取失败
    :param target_pos_array: 目标位置数组 可含None,对应舵机读取失败
    :return: 位置变化量数组
    :raises ValueError: 若两个数组长度不一致
    """
    if len(current_pos_array) != len(target_pos_array):
        raise ValueError(
            f"数组长度不匹配！当前数组: {len(current_pos_array)} 个元素, 目标数组: {len(target_pos_array)} 个元素"
        )
    
    pos_change_array = []
    for curr, target in zip(current_pos_array, target_pos_array):
        if curr is None or target is None:
            pos_change_array.append(None)
        else:
            pos_change_array.append(round(target - curr, 2))  # 保留2位小数（可选，避免浮点数冗余）
    return pos_change_array

def name_pos_dict(pose_name: str, pos_change_array: List[Optional[float]]) -> Dict[str, List[Optional[float]]]:
    """
    将一个 pose 名称和对应的位置/变化量数组组装成一个字典。
    :param pose_name: 位姿的名称 
    :param pos_change_array: 与该名称关联的位置或变化量数组 (list)
    :return: 一个格式为 {pose_name: pos_change_array} 的字典
    """
    if not isinstance(pose_name, str) or not pose_name.strip():
        raise ValueError("'pose_name' 必须是一个非空字符串。")
    if not isinstance(pos_change_array, list):
        raise ValueError("'pos_change_array' 必须是一个列表 (list)。")
    return {pose_name: pos_change_array}

def save_pos_json(
    pose_data: Union[Dict[str, List[Optional[float]]], List[Dict[str, List[Optional[float]]]]],
    filename: str = "pose_targets.json",
    mode: str = "update" # "update" 或 "overwrite"
) -> bool:
    """
    将位姿数据保存到JSON文件。
    :param pose_data: 可以是：
    1. 一个字典，例如: {"walk_forward": [10, 0, -5]}
    2. 一个字典列表，例如: [{"walk": [10,0,0]}, {"run": [20,0,0]}]
    :param filename: 保存的JSON文件名
    :param mode: "update" (默认) 表示如果文件存在，则追加或更新内容；"overwrite" 则总是创建新文件。
    :return: 布尔值，表示保存是否成功
    """
    final_data = {}

    # 如果是 "update" 模式并且文件已存在，则先读取现有内容
    if mode == "update":
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                final_data = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            # 如果文件不存在或损坏，则从头开始创建
            pass

    # 处理传入的 pose_data
    if isinstance(pose_data, dict):
        # 如果传入的是一个字典，就更新到 final_data 中
        final_data.update(pose_data)
    elif isinstance(pose_data, list):
        # 如果传入的是一个列表，就遍历列表并更新
        for item in pose_data:
            if isinstance(item, dict):
                final_data.update(item)
            else:
                print(f"警告: 列表中的元素 {item} 不是字典，已忽略。")
    else:
        print(f"错误: 'pose_data' 的类型 {type(pose_data)} 不支持。")
        return False

    if not final_data:
        print("错误: 没有有效的数据可以保存。")
        return False

    try:
        with open(filename, 'w', encoding='utf-8') as json_file:
            json.dump(final_data, json_file, ensure_ascii=False, indent=4)
        print(f"成功将位姿数据保存到文件: {filename}")
        return True
    except IOError as e:
        print(f"写入文件时发生错误: {e}")
        return False

def load_pos(
    filename: str = "pose_changes.json",
    pose_name: Optional[str] = None
) -> Tuple[Optional[List[Optional[float]]], Optional[Dict[str, List[Optional[float]]]]]:
    """
    从JSON文件读取位姿变化数组
    :param filename: JSON文件名
    :param pose_name: 要读取的特定pose名称 None则返回所有pose变化字典
    :return: 若指定pose_name, 返回 (该pose的变化数组, None)；否则返回 (None, 所有pose变化字典)；失败则返回 (None, None)
    """
    try:
        with open(filename, "r", encoding="utf-8") as f:
            json_data = json.load(f)

        # 自动兼容两种结构：{"pose_changes": {...}} 或 {...}
        pose_changes_dict = json_data.get("pose_changes", json_data)

        if not isinstance(pose_changes_dict, dict):
            print("错误:pose_changes字段或JSON根节点必须是字典类型!")
            return None, None

        if pose_name is not None:
            if pose_name not in pose_changes_dict:
                print(f"未在JSON中找到pose名称 '{pose_name}' (可选pose: {list(pose_changes_dict.keys())})")
                return None, None
            return pose_changes_dict[pose_name], None
        else:
            return None, pose_changes_dict

    except FileNotFoundError:
        print(f"错误:未找到JSON文件 '{filename}'!")
        return None, None
    except json.JSONDecodeError:
        print(f"错误:JSON文件 '{filename}' 解析失败(格式损坏)!")
        return None, None
    except Exception as e:
        print(f"读取JSON失败:{str(e)}")
        return None, None


def get_target_pos(
    # initial_pos_array: List[Optional[float]],
    # target_pos_name = input("输入位姿名称(数字):")
    # if target_pos_name.isdigit():
    #     target_pos = POSE_LIST[int(target_pos_name)]
    # else:
    #     raise ValueError("位姿名称输入错误，请输入数字对应位姿名称")
    # target_pos_change, _ = load_pos(pose_name=target_pos)
    
    # if len(initial_pos_array) != len(target_pos_change):
    #     raise ValueError(
    #         f"数组长度不匹配！当前数组: {len(initial_pos_array)} 个元素, 目标数组: {len(target_pos_array)} 个元素"
    #     )
    
    # target_pos_array = []
    # for init, change in zip(initial_pos_array, target_pos_change):
    #     if init is None or change is None:
    #         target_pos_array.append(None)
    #     else:
    #         target_pos_array.append(round(change + init, 2))  # 保留2位小数（可选，避免浮点数冗余）
    # if target_pos_array is None:
    #     raise ValueError("目标位置数组不能为空")
    # else:
    #     return target_pos_array
    filename: str = "pose_targets.json",
) -> List[Optional[float]]:
    """
    现在不再用“变化量”，而是直接从 JSON 中读取每个舵机的目标位置矩阵。

    initial_pos_array 只用于做长度检查（确认舵机数量一致），
    真正的目标位置由 JSON 中的数组直接给出。
    """

    # 选姿态
    target_pos_name = input("输入位姿名称(数字):").strip()
    if not target_pos_name.isdigit():
        raise ValueError("位姿名称输入错误，请输入数字对应位姿名称")

    pose_index = int(target_pos_name)

    try:
        pose_key = POSE_LIST[pose_index]  # 来自 sms_sts.py
    except (IndexError, TypeError):
        raise ValueError(f"位姿索引 {pose_index} 超出 POSE_LIST 范围，请检查配置。")

    # 直接读取该位姿下的“目标位置矩阵”
    target_pos_array, _ = load_pos(filename=filename, pose_name=pose_key)

    if target_pos_array is None:
        raise ValueError(f"在文件 {filename} 中未找到位姿 '{pose_key}' 的数据")

    # 长度检查：和当前控制的舵机数量要一致
    # if len(initial_pos_array) != len(target_pos_array):
    #     raise ValueError(
    #         f"数组长度不匹配！当前数组: {len(initial_pos_array)} 个元素, "
    #         f"目标位置数组: {len(target_pos_array)} 个元素"
    #     )
    return target_pos_array