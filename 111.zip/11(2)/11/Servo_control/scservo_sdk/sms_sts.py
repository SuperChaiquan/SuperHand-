#!/usr/bin/env python

from .scservo_def import *
from .protocol_packet_handler import *
from .group_sync_read import *
from .group_sync_write import *
import time

SERVO_IDS = [1, 2, 3, 4, 5, 6, 7,8,9,10,11,12,13,14,15,16]
FINGER_SERVO_IDS = [1, 2, 3, 4, 5, 6, 7, 8, 13, 14, 15, 16]
THUMB_SERVO_IDS  = [9,10,11,12]
POSE_LIST = ["球","魔方","水瓶","液体","弹簧","布料","卡片","尼龙","图钉","ka"]
INITIAL_POS_ARRAY = [2501, 2000, 2495, 2502, 2005, 2000, 2489, 2504, 2500, 2499, 2503, 2497, 2500, 2500, 2502, 2502]

#波特率定义
SMS_STS_1M = 0
SMS_STS_0_5M = 1
SMS_STS_250K = 2
SMS_STS_128K = 3
SMS_STS_115200 = 4
SMS_STS_76800 = 5
SMS_STS_57600 = 6
SMS_STS_38400 = 7

#内存表定义
#-------EPROM(只读)--------
SMS_STS_MODEL_L = 3
SMS_STS_MODEL_H = 4

#-------EPROM(读写)--------
SMS_STS_ID = 5
SMS_STS_BAUD_RATE = 6
SMS_STS_MIN_ANGLE_LIMIT_L = 9
SMS_STS_MIN_ANGLE_LIMIT_H = 10
SMS_STS_MAX_ANGLE_LIMIT_L = 11
SMS_STS_MAX_ANGLE_LIMIT_H = 12
SMS_STS_CW_DEAD = 26
SMS_STS_CCW_DEAD = 27
SMS_STS_OFS_L = 31
SMS_STS_OFS_H = 32
SMS_STS_MODE = 33

#-------SRAM(读写)--------
SMS_STS_TORQUE_ENABLE = 40
SMS_STS_ACC = 41
SMS_STS_GOAL_POSITION_L = 42
SMS_STS_GOAL_POSITION_H = 43
SMS_STS_GOAL_TIME_L = 44
SMS_STS_GOAL_TIME_H = 45
SMS_STS_GOAL_SPEED_L = 46
SMS_STS_GOAL_SPEED_H = 47
SMS_STS_LOCK = 55

#-------SRAM(只读)--------
SMS_STS_PRESENT_POSITION_L = 56
SMS_STS_PRESENT_POSITION_H = 57
SMS_STS_PRESENT_SPEED_L = 58
SMS_STS_PRESENT_SPEED_H = 59
SMS_STS_PRESENT_LOAD_L = 60
SMS_STS_PRESENT_LOAD_H = 61
SMS_STS_PRESENT_VOLTAGE = 62
SMS_STS_PRESENT_TEMPERATURE = 63
SMS_STS_MOVING = 66
SMS_STS_PRESENT_CURRENT_L = 69
SMS_STS_PRESENT_CURRENT_H = 70


#-------Basic Functions-------
class sms_sts(protocol_packet_handler):
    def __init__(self, portHandler):
        protocol_packet_handler.__init__(self, portHandler, 0)
        self.groupSyncWrite = GroupSyncWrite(self, SMS_STS_ACC, 7)

    def WritePosEx(self, scs_id, position, speed, acc):
        position = self.scs_toscs(position, 15)
        txpacket = [acc, self.scs_lobyte(position), self.scs_hibyte(position), 0, 0, self.scs_lobyte(speed), self.scs_hibyte(speed)]
        return self.writeTxRx(scs_id, SMS_STS_ACC, len(txpacket), txpacket)

    def ReadPos(self, scs_id):
        scs_present_position, scs_comm_result, scs_error = self.read2ByteTxRx(scs_id, SMS_STS_PRESENT_POSITION_L)
        return self.scs_tohost(scs_present_position, 15), scs_comm_result, scs_error

    def ReadSpeed(self, scs_id):
        scs_present_speed, scs_comm_result, scs_error = self.read2ByteTxRx(scs_id, SMS_STS_PRESENT_SPEED_L)
        return self.scs_tohost(scs_present_speed, 15), scs_comm_result, scs_error

    def ReadPosSpeed(self, scs_id):
        scs_present_position_speed, scs_comm_result, scs_error = self.read4ByteTxRx(scs_id, SMS_STS_PRESENT_POSITION_L)
        scs_present_position = self.scs_loword(scs_present_position_speed)
        scs_present_speed = self.scs_hiword(scs_present_position_speed)
        return self.scs_tohost(scs_present_position, 15), self.scs_tohost(scs_present_speed, 15), scs_comm_result, scs_error

    def ReadMoving(self, scs_id):
        moving, scs_comm_result, scs_error = self.read1ByteTxRx(scs_id, SMS_STS_MOVING)
        return moving, scs_comm_result, scs_error

    def SyncWritePosEx(self, scs_id, position, speed, acc):
        position = self.scs_toscs(position, 15)
        txpacket = [acc, self.scs_lobyte(position), self.scs_hibyte(position), 0, 0, self.scs_lobyte(speed), self.scs_hibyte(speed)]
        return self.groupSyncWrite.addParam(scs_id, txpacket)

    def RegWritePosEx(self, scs_id, position, speed, acc):
        position = self.scs_toscs(position, 15)
        txpacket = [acc, self.scs_lobyte(position), self.scs_hibyte(position), 0, 0, self.scs_lobyte(speed), self.scs_hibyte(speed)]
        return self.regWriteTxRx(scs_id, SMS_STS_ACC, len(txpacket), txpacket)

    def RegAction(self):
        return self.action(BROADCAST_ID)

    def WheelMode(self, scs_id):
        return self.write1ByteTxRx(scs_id, SMS_STS_MODE, 1)

    def WriteSpec(self, scs_id, speed, acc):
        speed = self.scs_toscs(speed, 15)
        txpacket = [acc, 0, 0, 0, 0, self.scs_lobyte(speed), self.scs_hibyte(speed)]
        return self.writeTxRx(scs_id, SMS_STS_ACC, len(txpacket), txpacket)

    def LockEprom(self, scs_id):
        return self.write1ByteTxRx(scs_id, SMS_STS_LOCK, 1)

    def unLockEprom(self, scs_id):
        return self.write1ByteTxRx(scs_id, SMS_STS_LOCK, 0)
    
#--------------------------------------------------------------------------------------------
#新增：配置舵机ID
    def configure_servo_id(self, old_id, new_id):
        # 1. 解锁EPROM（允许修改配置）
        self.unLockEprom(old_id)
        # 2. 写入新ID
        write_result, write_error = self.write1ByteTxRx(old_id, SMS_STS_ID, new_id)
        if write_result != COMM_SUCCESS or write_error != 0:
            print(f"写入新ID失败!通信结果:{self.getTxRxResult(write_result)}，错误码：{write_error}")
            return False
        # 3. 锁定EPROM
        self.LockEprom(new_id)
        print(f"成功将ID {old_id} 修改为 {new_id}")
        # 4. 校验新ID
        read_data, read_result, read_error = self.read1ByteTxRx(new_id, SMS_STS_ID)
        if read_result != COMM_SUCCESS or read_error != 0:
            print(f"读取新ID失败!通信结果：{self.getTxRxResult(read_result)}，错误码：{read_error}")
            return False
        if read_data == new_id:
            print(f"Success! 新ID:{read_data}（与写入值{new_id}一致）")
            return True
        else:
            print(f"Failed! 写入值{new_id}，读取值{read_data}")
            # 清理缓冲区
            self.portHandler.flushInput()
            self.portHandler.flushOutput()
            return False

# 新增：验证零位位置
    def verify_zero_position(self, servo_id, max_retry=3, error_threshold=5, wait_time=5.0):
        retry_count = 0
        while retry_count < max_retry:
            # 读取当前位置
            current_pos, read_result, read_error = self.ReadPos(servo_id)
            
            if read_result != COMM_SUCCESS or read_error != 0:
                print(f"舵机ID={servo_id} 第{retry_count+1}次读取位置失败！通信错误={read_result}，舵机错误={read_error}")
                retry_count += 1
                time.sleep(0.5)
                continue
            
            # 检查是否在允许范围内
            if abs(current_pos - 0) <= error_threshold:
                print(f"舵机ID={servo_id} 校验通过！当前位置：{current_pos}（误差≤{error_threshold}）")
                return True
            
            # 首次失败时发送归零指令
            if retry_count == 0:
                print(f"舵机ID={servo_id} 未到达0度. 当前位置：{current_pos}, 正在移动到0度...")
                write_result, write_error = self.WritePosEx(servo_id, position=0, speed=50, acc=30)
                if write_result != COMM_SUCCESS or write_error != 0:
                    print(f"发送移动指令失败！通信错误={write_result}，舵机错误={write_error}")
                    retry_count += 1
                    continue
                time.sleep(wait_time)
            
            retry_count += 1
        
        # 所有重试失败
        print(f"舵机ID={servo_id} 超出最大重试次数, 未成功到达0度，最终位置：{current_pos}")
        return False

#新增：读取多个舵机位置
    def read_multi_positions(self, servo_ids):
        """
        同时读取数组中所有舵机的当前位置，结果存储在数组中
        servo_ids: 舵机ID列表 如[2,3,4]
        return: 位置结果字典 key=舵机ID, value=(当前位置, 读取状态)+ 整体成功标识
        """
        pos_results = {} # 存储结果：{id: (current_pos, is_success)}
        all_success = True

        print(f"\n===== 开始读取 {len(servo_ids)} 个舵机位置 =====")
        for sid in servo_ids:
            current_pos, read_result, read_error = self.ReadPos(sid)
            
            if read_result == COMM_SUCCESS and read_error == 0:
                pos_results[sid] = (current_pos, True)
                print(f"舵机ID={sid} | 当前位置：{current_pos}")
            else:
                pos_results[sid] = (None, False)
                print(f"舵机ID={sid} | 读取失败！通信错误={read_result}，舵机错误={read_error}")
                all_success = False

        pos_array = [pos_results[sid][0] for sid in servo_ids]
        print(f"位置数组:{pos_array}")
        return pos_results, pos_array, all_success

#新增：同步控制多个舵机
    def multi_servos_to_target(self, servo_ids, target_positions, speed=100, acc=50):
        """
        同时控制数组中所有舵机到不同目标位置（同步执行，无先后顺序）
        servo_ids: 舵机ID列表 如[2,3,4]
        target_positions: 目标位置列表 与ID列表一一对应,如[0, 300, 600]
        speed: 转动速度 0~1023, 0=最快）
        acc: 加速度 0~254, 0=无加速
        return: 控制是否成功
        """
        # 校验：ID数量与目标位置数量必须一致
        if len(servo_ids) != len(target_positions):
            print(f"错误：舵机数量（{len(servo_ids)}）与目标位置数量（{len(target_positions)}）不匹配！")
            return False

        print(f"\n===== 开始控制 {len(servo_ids)} 个舵机到目标位置 =====")
        self.groupSyncWrite.clearParam()
        all_success = True
        # 为每个舵机添加“ID+目标位置+速度+加速度”参数
        for sid, target_pos in zip(servo_ids, target_positions):
            result = self.SyncWritePosEx(sid, target_pos, speed, acc)
            if result:
                print(f"舵机ID={sid} | 目标位置：{target_pos}，速度：{speed}，加速度：{acc}")
            else:
                print(f"舵机ID={sid} | 添加目标位置{target_pos}失败！")
                all_success = False
        # 运动指令
        if all_success:
            tx_result = self.groupSyncWrite.txPacket()
            if tx_result == COMM_SUCCESS:
                print("所有舵机同步控制指令发送成功！")
                wait_time = max(target_positions) / speed if speed != 0 else 1.0
                wait_time = min(wait_time + 0.5, 3.0)
                print(f"等待 {wait_time:.1f} 秒让舵机完成动作...")
                time.sleep(wait_time)
                return True
            else:
                print(f"同步指令发送失败！通信错误={tx_result}")
                return False
        else:
            print("部分舵机参数添加失败，取消控制！")
            return False

#新增：验证多个舵机是否到达目标位置
    def verify_movements_to_target(self, servo_ids, target_positions, error_threshold=5):
        # 校验：ID数量与目标位置数量必须一致
        if len(servo_ids) != len(target_positions):
            print(f"验证失败：舵机数量（{len(servo_ids)}）与目标位置数量（{len(target_positions)}）不匹配！")
            return False

        print(f"\n===== 验证 {len(servo_ids)} 个舵机是否到达 (误差阈值 ±{error_threshold}) =====")
        servo_target_map = dict(zip(servo_ids, target_positions))
        all_in_place = True
        
        # 逐个验证每个舵机位置
        for sid, target_pos in servo_target_map.items():
            current_pos, read_result, read_error = self.ReadPos(sid)

            # 处理读取失败情况
            if read_result != COMM_SUCCESS or read_error != 0:
                print(f"舵机ID={sid}: 读取位置失败！通信错误={read_result}，舵机错误={read_error}")
                all_in_place = False
                continue
            
            # 判断误差是否在允许范围内
            position_error = abs(current_pos - target_pos)
            if position_error <= error_threshold:
                print(f"舵机ID={sid}: 已到达目标位置。当前={current_pos}, 目标={target_pos}, 误差={position_error}")
            else:
                print(f"舵机ID={sid}: 未到达目标位置。当前={current_pos}, 目标={target_pos}, 误差={position_error} (超过阈值 {error_threshold})")
                all_in_place = False

        if all_in_place:
            print("===== 所有舵机达到目标位置 =====")
        else:
            print("\n===== 验证完毕，部分舵机没有到达 =====")
        return all_in_place
